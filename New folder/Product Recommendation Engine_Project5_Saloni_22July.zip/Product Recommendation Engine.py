#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd
import numpy as np
from scipy import stats
import random

# Helper function to introduce missing values and outliers
def introduce_anomalies(data, missing_percentage=0.1, outlier_percentage=0.05):
    # Introduce missing values
    total_elements = data.size
    num_missing = int(total_elements * missing_percentage)
    missing_indices = random.sample(range(total_elements), num_missing)
    data_flat = data.flatten()
    for idx in missing_indices:
        data_flat[idx] = np.nan

    # Introduce outliers
    num_outliers = int(total_elements * outlier_percentage)
    outlier_indices = random.sample(range(total_elements), num_outliers)
    for idx in outlier_indices:
        if not np.isnan(data_flat[idx]):
            data_flat[idx] *= np.random.randint(2, 10)  # Outliers are random multiples of the existing value

    return data_flat.reshape(data.shape)

# Generate synthetic data
num_rows = 1000
data = {
    "Customer_ID": np.arange(1, num_rows + 1),
    "Age": np.random.randint(18, 80, num_rows),
    "Gender": np.random.choice(['Male', 'Female', 'Other'], num_rows),
    "Income": np.random.uniform(20000, 200000, num_rows),
    "Monthly_Spending": np.random.uniform(100, 2000, num_rows),
    "Annual_Spending": np.random.uniform(1200, 24000, num_rows),
    "Product_Usage_Frequency": np.random.randint(0, 50, num_rows),
    "Lifetime_Value": np.random.uniform(1000, 100000, num_rows),
    "State": np.random.choice(['NY', 'CA', 'TX', 'FL', 'IL'], num_rows),
    "City": np.random.choice(['New York', 'Los Angeles', 'Houston', 'Miami', 'Chicago'], num_rows),
    "Zip_Code": np.random.randint(10000, 99999, num_rows),
    "Loyalty_Score": np.random.randint(1, 11, num_rows),
    "Membership_Status": np.random.choice(['Gold', 'Silver', 'Bronze'], num_rows),
    "Last_Purchase_Date": pd.to_datetime('today') - pd.to_timedelta(np.random.randint(1, 365*5, num_rows), unit='d'),
    "Email_Opt_In": np.random.choice(['Yes', 'No'], num_rows)
}

# Create DataFrame
df_segmentation = pd.DataFrame(data)

# Introduce missing values and outliers
for column in df_segmentation.columns[1:]:  # Skip Customer_ID for anomalies
    df_segmentation[column] = introduce_anomalies(df_segmentation[column].values)

# Save to CSV
df_segmentation.to_csv('customer_segmentation_data.csv', index=False)

print("Dataset created and saved as 'customer_segmentation_data.csv'")
# Load the dataset
df = pd.read_csv('customer_segmentation_data.csv')

# Step 1: Handling Missing Values
# Visualize missing values
print(df.isnull().sum())

# Example: Impute missing numerical values with the median
numerical_columns = df.select_dtypes(include=[np.number]).columns
for column in numerical_columns:
    df[column].fillna(df[column].median(), inplace=True)

# Example: Impute missing categorical values with the mode
categorical_columns = df.select_dtypes(include=[object]).columns
for column in categorical_columns:
    df[column].fillna(df[column].mode()[0], inplace=True)

# Step 2: Handling Outliers
# Identify outliers using z-score
z_scores = np.abs(stats.zscore(df.select_dtypes(include=[np.number])))
outliers = (z_scores > 3).all(axis=1)
df[outliers] = np.nan  # Option to mark outliers as NaN

# Impute outliers with the median
for column in numerical_columns:
    df[column].fillna(df[column].median(), inplace=True)

# Step 3: Recoding Values
# Example: Recode 'Yes'/'No' to 1/0
df['Email_Opt_In'] = df['Email_Opt_In'].map({'Yes': 1, 'No': 0})

# Step 4: Correcting Data Types
# Convert 'Last_Purchase_Date' to datetime
df['Last_Purchase_Date'] = pd.to_datetime(df['Last_Purchase_Date'])

# Step 5: Handling Duplicates
# Remove duplicate rows
df.drop_duplicates(inplace=True)

# Step 6: Feature Engineering
# Example: Create an Age Group feature
df['Age_Group'] = pd.cut(df['Age'], bins=[18, 29, 39, 49, 59, 69, 80], labels=['18-29', '30-39', '40-49', '50-59', '60-69', '70-80'])

# Normalize numerical features
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
df[numerical_columns] = scaler.fit_transform(df[numerical_columns])

# Save the cleaned dataset
df.to_csv('cleaned_customer_segmentation_data.csv', index=False)

print("Data cleaning completed and saved as 'cleaned_customer_segmentation_data.csv'")


# In[4]:


import pandas as pd
import numpy as np
import random

# Helper function to introduce missing values and outliers
def introduce_anomalies(data, missing_percentage=0.1, outlier_percentage=0.05):
    # Introduce missing values
    total_elements = data.size
    num_missing = int(total_elements * missing_percentage)
    missing_indices = random.sample(range(total_elements), num_missing)
    data_flat = data.flatten()
    for idx in missing_indices:
        data_flat[idx] = np.nan

    # Introduce outliers
    num_outliers = int(total_elements * outlier_percentage)
    outlier_indices = random.sample(range(total_elements), num_outliers)
    for idx in outlier_indices:
        if not np.isnan(data_flat[idx]):
            data_flat[idx] *= np.random.randint(2, 10)  # Outliers are random multiples of the existing value

    return data_flat.reshape(data.shape)

# Generate synthetic data
num_rows = 1000
data = {
    "Customer_ID": np.arange(1, num_rows + 1),
    "Age": np.random.randint(18, 80, num_rows).astype(float),  # Convert to float
    "Gender": np.random.choice(['Male', 'Female', 'Other'], num_rows),
    "Income": np.random.uniform(20000, 200000, num_rows),
    "Monthly_Spending": np.random.uniform(100, 2000, num_rows),
    "Annual_Spending": np.random.uniform(1200, 24000, num_rows),
    "Product_Usage_Frequency": np.random.randint(0, 50, num_rows).astype(float),  # Convert to float
    "Lifetime_Value": np.random.uniform(1000, 100000, num_rows),
    "State": np.random.choice(['NY', 'CA', 'TX', 'FL', 'IL'], num_rows),
    "City": np.random.choice(['New York', 'Los Angeles', 'Houston', 'Miami', 'Chicago'], num_rows),
    "Zip_Code": np.random.randint(10000, 99999, num_rows).astype(float),  # Convert to float
    "Loyalty_Score": np.random.randint(1, 11, num_rows).astype(float),  # Convert to float
    "Membership_Status": np.random.choice(['Gold', 'Silver', 'Bronze'], num_rows),
    "Last_Purchase_Date": pd.to_datetime('today') - pd.to_timedelta(np.random.randint(1, 365*5, num_rows), unit='d'),
    "Email_Opt_In": np.random.choice(['Yes', 'No'], num_rows)
}

# Create DataFrame
df_segmentation = pd.DataFrame(data)

# Introduce missing values and outliers
for column in df_segmentation.columns[1:]:  # Skip Customer_ID for anomalies
    df_segmentation[column] = introduce_anomalies(df_segmentation[column].values)

# Save to CSV
df_segmentation.to_csv('customer_segmentation_data.csv', index=False)

print("Dataset created and saved as 'customer_segmentation_data.csv'")


# In[5]:


import pandas as pd
import numpy as np
import random

# Helper function to introduce missing values and outliers for numeric data
def introduce_anomalies_numeric(data, missing_percentage=0.1, outlier_percentage=0.05):
    # Introduce missing values
    total_elements = data.size
    num_missing = int(total_elements * missing_percentage)
    missing_indices = random.sample(range(total_elements), num_missing)
    data_flat = data.flatten()
    for idx in missing_indices:
        data_flat[idx] = np.nan

    # Introduce outliers
    num_outliers = int(total_elements * outlier_percentage)
    outlier_indices = random.sample(range(total_elements), num_outliers)
    for idx in outlier_indices:
        if not np.isnan(data_flat[idx]):
            data_flat[idx] *= np.random.randint(2, 10)  # Outliers are random multiples of the existing value

    return data_flat.reshape(data.shape)

# Helper function to introduce missing values for non-numeric data
def introduce_anomalies_non_numeric(data, missing_percentage=0.1):
    # Introduce missing values
    total_elements = data.size
    num_missing = int(total_elements * missing_percentage)
    missing_indices = random.sample(range(total_elements), num_missing)
    data_flat = data.flatten()
    for idx in missing_indices:
        data_flat[idx] = np.nan

    return data_flat.reshape(data.shape)

# Generate synthetic data
num_rows = 1000
data = {
    "Customer_ID": np.arange(1, num_rows + 1),
    "Age": np.random.randint(18, 80, num_rows).astype(float),  # Convert to float
    "Gender": np.random.choice(['Male', 'Female', 'Other'], num_rows),
    "Income": np.random.uniform(20000, 200000, num_rows),
    "Monthly_Spending": np.random.uniform(100, 2000, num_rows),
    "Annual_Spending": np.random.uniform(1200, 24000, num_rows),
    "Product_Usage_Frequency": np.random.randint(0, 50, num_rows).astype(float),  # Convert to float
    "Lifetime_Value": np.random.uniform(1000, 100000, num_rows),
    "State": np.random.choice(['NY', 'CA', 'TX', 'FL', 'IL'], num_rows),
    "City": np.random.choice(['New York', 'Los Angeles', 'Houston', 'Miami', 'Chicago'], num_rows),
    "Zip_Code": np.random.randint(10000, 99999, num_rows).astype(float),  # Convert to float
    "Loyalty_Score": np.random.randint(1, 11, num_rows).astype(float),  # Convert to float
    "Membership_Status": np.random.choice(['Gold', 'Silver', 'Bronze'], num_rows),
    "Last_Purchase_Date": pd.to_datetime('today') - pd.to_timedelta(np.random.randint(1, 365*5, num_rows), unit='d'),
    "Email_Opt_In": np.random.choice(['Yes', 'No'], num_rows)
}

# Create DataFrame
df_segmentation = pd.DataFrame(data)

# Introduce missing values and outliers for numeric columns
numeric_columns = df_segmentation.select_dtypes(include=[np.number]).columns
for column in numeric_columns:
    df_segmentation[column] = introduce_anomalies_numeric(df_segmentation[column].values)

# Introduce missing values for non-numeric columns
non_numeric_columns = df_segmentation.select_dtypes(exclude=[np.number]).columns
for column in non_numeric_columns:
    df_segmentation[column] = introduce_anomalies_non_numeric(df_segmentation[column].values)

# Save to CSV
df_segmentation.to_csv('customer_segmentation_data.csv', index=False)

print("Dataset created and saved as 'customer_segmentation_data.csv'")


# In[ ]:




